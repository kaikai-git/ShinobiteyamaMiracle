using System.Collections.Generic;
using System.Linq;
using UnityEngine;

/// <summary>
/// ��b���̃f�[�^�x�[�X���X�g
/// </summary>
[CreateAssetMenu]

public class ConversationDataBase : ScriptableObject
{
    public List<ConversationData> conversationDataList = new List<ConversationData>();

    public ConversationData GetConversationByID(int id)
    {
        return conversationDataList.FirstOrDefault(conversation => conversation.ConversationID == id);
    }

}
