
public class DocumentReadingState : Player.IPlayerState
{
    Player.PlayerInputHandler playerInputHandler;


    public DocumentReadingState(Player.PlayerInputHandler _playerInputHandler)
    {
        playerInputHandler = _playerInputHandler;
    }
    public void EnterState()
    {
        playerInputHandler.SwitchEnableReadingDocumentAction(Player.PlayerInputHandler.EnableState.ENABLE);     //�Y���A�N�V������L����
    }

    public void UpdateState()
    {
        // playerInputHandler.OnExploreAction();
    }
    public void ExitState()
    {
        UI.Document.DocumentUIManager.Instance.UnSetDocumentUI();
        playerInputHandler.SwitchEnableReadingDocumentAction(Player.PlayerInputHandler.EnableState.DISABLE);      //�Y���A�N�V�����𖳌���
    }
}
