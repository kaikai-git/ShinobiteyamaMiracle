using UnityEngine;

public class R : MonoBehaviour
{
    [SerializeField] ItemDataBase itemData;
    [SerializeField] DocumentDataBase documentData;

    void Start()
    {
        //SoundManager.Instance.PlaySE(SEType.CANCEL_UI);
    }

    private void Update()
    {
        //Debug.Log(itemData.GetItemById(0).ItemName);

        //Debug.Log(documentData.GetItemById(0).DocumentName);

        ////�e�y�[�W���o��
        //for (int i = 0; i < documentData.GetItemById(0).pages.Count; i++)
        //{
        //    // �C���f�b�N�X���w�肵�ē��e���擾
        //    Debug.Log($"�y�[�W {i + 1}: {documentData.GetItemById(0).GetPageContent(i)}");
        //}

    }
}
