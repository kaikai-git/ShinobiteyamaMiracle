using UnityEngine;
using UnityEngine.Localization.Settings;
using System.Threading.Tasks;


namespace Setting
{
    //����ύX���Ǘ�����N���X
    public class LocalizeManager : MonoBehaviour
    {
        public enum LanguageType
        {
            English,
            Japanese,
        }
        static LanguageType currentLanguageType = LanguageType.Japanese;

      


        public static async Task ChangeLocale(LanguageType languageType)
        {
            string key = "";
            switch(languageType)
            {
                case LanguageType.English:
                    key = "en";
                    break;

                case LanguageType.Japanese:
                    key = "ja";
                    break;
            }
            // �w�肵��Locale���擾
            var locale = LocalizationSettings.AvailableLocales.Locales.Find((x) => x.Identifier.Code == key);

            // Locale�̐ݒ�
            LocalizationSettings.SelectedLocale = locale;

            // �������҂�
            await LocalizationSettings.InitializationOperation.Task;
        }
    }

}

