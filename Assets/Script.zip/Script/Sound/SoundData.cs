using UnityEngine;


public enum SEType
{
    [InspectorName("SE/UI:����")] DECIDE_UI,
    [InspectorName("SE/UI:�L�����Z��")] CANCEL_UI
}

public enum BGMType
{
    [InspectorName("BGM/�^�C�g��BGM")] TITLE_BGM,
    [InspectorName("BGM/�Q�[����BGM")] GAME_BGM
}
public class SoundData
{
   public AudioClip audioClip;

}

[System.Serializable]

public class SEData : SoundData
{
    public SEType seType;
}
[System.Serializable]

public class  BGMData : SoundData
{
    public BGMType bgmType;


}

